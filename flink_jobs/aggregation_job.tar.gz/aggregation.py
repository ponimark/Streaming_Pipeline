from pyflink.datastream import StreamExecutionEnvironment
from pyflink.datastream.connectors.kafka import KafkaSource, KafkaOffsetsInitializer
from pyflink.datastream.connectors.jdbc import JdbcSink, JdbcConnectionOptions, JdbcExecutionOptions
from pyflink.common.typeinfo import Types
from pyflink.common.serialization import SimpleStringSchema
from pyflink.common.watermark_strategy import WatermarkStrategy

import json

# ✅ Direct Kafka & Postgres Configs
KAFKA_BOOTSTRAP_SERVERS = "kafka:9092"
KAFKA_TOPIC = "app_events"
KAFKA_GROUP_ID = "flink_consumer_group"

POSTGRES_JDBC_URL = "jdbc:postgresql://host.docker.internal:5432/postgres"
POSTGRES_USER = "postgres"
POSTGRES_PASSWORD = "poni"

# ✅ FLINK ENVIRONMENT
env = StreamExecutionEnvironment.get_execution_environment()

# ✅ KAFKA SOURCE
kafka_source = KafkaSource.builder() \
    .set_bootstrap_servers(KAFKA_BOOTSTRAP_SERVERS) \
    .set_topics(KAFKA_TOPIC) \
    .set_group_id(KAFKA_GROUP_ID) \
    .set_starting_offsets(KafkaOffsetsInitializer.earliest()) \
    .set_value_only_deserializer(SimpleStringSchema()) \
    .build()

ds = env.from_source(
    source=kafka_source,
    watermark_strategy=WatermarkStrategy.for_monotonous_timestamps(),
    source_name="Kafka Source"
)

# ✅ PARSE EVENTS
def parse_event(event_str):
    e = json.loads(event_str)
    return (
        e["app_id"],
        1,  # download count
        e["rating"] if e.get("rating") else 0.0
    )

parsed_ds = ds.map(parse_event, output_type=Types.TUPLE([Types.INT(), Types.INT(), Types.FLOAT()]))

# ✅ AGGREGATION
agg_ds = parsed_ds.key_by(lambda x: x[0]) \
    .reduce(lambda a, b: (a[0], a[1] + b[1], a[2] + b[2]))

# ✅ JDBC SINK (Flink 1.18+ Compatible)
jdbc_sink = JdbcSink.sink(
    "INSERT INTO apple_app_aggregates (app_id, window_start, window_end, downloads, avg_rating) "
    "VALUES (?, now(), now(), ?, ?) "
    "ON CONFLICT (app_id, window_start) DO UPDATE SET downloads = EXCLUDED.downloads, avg_rating = EXCLUDED.avg_rating",
    lambda stmt, t: [
        stmt.setInt(1, t[0]),
        stmt.setInt(2, t[1]),
        stmt.setFloat(3, float(t[2]) / t[1] if t[1] > 0 else 0.0)
    ],
    JdbcExecutionOptions.builder()
        .with_batch_size(1)
        .with_batch_interval_ms(200)
        .with_max_retries(3)
        .build(),
    JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
        .with_url(POSTGRES_JDBC_URL)
        .with_driver_name("org.postgresql.Driver")
        .with_user_name(POSTGRES_USER)
        .with_password(POSTGRES_PASSWORD)
        .build()
)

agg_ds.add_sink(jdbc_sink)

# ✅ EXECUTE JOB
env.execute("Flink Real-Time Aggregates")
